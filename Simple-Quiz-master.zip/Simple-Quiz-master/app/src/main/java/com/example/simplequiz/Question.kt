package com.example.simplequiz

data class Question(var theQuestion: String, var answerGroup:ArrayList<String>){}